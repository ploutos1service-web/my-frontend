import api from './api';
import { Artist, ArtistCategory } from '../pages/types';

// Adapter function to convert Backend Artist to Frontend Artist
const adaptArtist = (backendArtist: any): Artist => {
    return {
        id: backendArtist._id,
        name: backendArtist.stageName,
        category: backendArtist.category || ArtistCategory.DJ, // Default or map if backend has category field
        genres: backendArtist.genres || [],
        rating: backendArtist.rating || 0,
        reviewCount: backendArtist.reviewCount || 0,
        location: backendArtist.location?.city || 'Unknown Location',
        image: backendArtist.profilePhoto || 'https://via.placeholder.com/800x600',
        gallery: backendArtist.galleryPhotos || [],
        priceWithSono: backendArtist.priceWithSono,
        priceWithoutSono: backendArtist.priceWithoutSono,
        maxTravelKm: backendArtist.maxTravelDistance,
        isLastMinuteAvailable: backendArtist.lastMinuteAvailable,
        description: backendArtist.bio || '',
        reviews: [], // Backend might not send reviews in list, or we need to fetch separately
        videoUrl: backendArtist.videos?.[0]?.url
    };
};

export const artistService = {
    getAllArtists: async (): Promise<Artist[]> => {
        try {
            const response = await api.get('/artists');
            return response.data.map(adaptArtist);
        } catch (error) {
            console.error('Error fetching artists:', error);
            return [];
        }
    },

    getArtistById: async (id: string): Promise<Artist | null> => {
        try {
            const response = await api.get(`/artists/${id}`);
            return adaptArtist(response.data);
        } catch (error) {
            console.error(`Error fetching artist ${id}:`, error);
            return null;
        }
    }
};
